def merge_intervals(intervals):
    if any(start > end for start, end in intervals):
        raise ValueError("an interval starts after it ends")

    ordered = sorted(intervals)
    merged = []

    i = 0
    while i < len(ordered):
        start, end = ordered[i]
        j = i + 1
        while j < len(ordered) and ordered[j][0] - end <= 1:
            end = max(end, ordered[j][1])
            j += 1
        merged.append((start, end))
        i = j

    return merged
