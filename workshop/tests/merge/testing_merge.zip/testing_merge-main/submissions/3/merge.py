def merge_intervals(intervals):
    if any(start > end for start, end in intervals):
        raise ValueError("an interval starts after it ends")

    stack = []
    for start, end in sorted(intervals):
        if stack and start < stack[-1][1]:
            top_start, top_end = stack.pop()
            stack.append((top_start, max(top_end, end)))
        else:
            stack.append((start, end))

    return stack
