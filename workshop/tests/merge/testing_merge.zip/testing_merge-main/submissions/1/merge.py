from functools import reduce


def merge_intervals(intervals):
    if any(start > end for start, end in intervals):
        raise ValueError("an interval starts after it ends")

    def fold(merged, current):
        if merged and current[0] <= merged[-1][1]:
            return merged[:-1] + [(merged[-1][0], current[1])]
        return merged + [current]

    return reduce(fold, sorted(intervals), [])
