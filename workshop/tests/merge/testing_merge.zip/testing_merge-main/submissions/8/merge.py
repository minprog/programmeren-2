def merge_intervals(intervals):
    if any(start > end for start, end in intervals):
        raise ValueError("an interval starts after it ends")

    def stream():
        current = None
        for start, end in intervals:
            if current is None:
                current = (start, end)
            elif start <= current[1]:
                current = (current[0], max(current[1], end))
            else:
                yield current
                current = (start, end)
        if current is not None:
            yield current

    return list(stream())
