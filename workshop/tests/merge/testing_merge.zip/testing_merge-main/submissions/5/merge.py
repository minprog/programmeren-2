OPEN, CLOSE = 0, 1


def merge_intervals(intervals):
    if any(start > end for start, end in intervals):
        raise ValueError("an interval starts after it ends")

    events = []
    for start, end in intervals:
        if start == end:
            continue
        events.append((start, OPEN))
        events.append((end, CLOSE))
    events.sort()

    merged = []
    depth = 0
    for position, kind in events:
        if kind == OPEN:
            if depth == 0:
                opened_at = position
            depth += 1
        else:
            depth -= 1
            if depth == 0:
                merged.append((opened_at, position))

    return merged
