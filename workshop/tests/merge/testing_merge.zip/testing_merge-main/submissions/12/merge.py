def normalised(intervals):
    for a, b in intervals:
        yield (min(a, b), max(a, b))


def combined(pairs):
    current = None
    for start, end in pairs:
        if current is not None and start <= current[1]:
            current = (current[0], max(current[1], end))
        else:
            if current is not None:
                yield current
            current = (start, end)
    if current is not None:
        yield current


def merge_intervals(intervals):
    return list(combined(sorted(normalised(intervals))))
