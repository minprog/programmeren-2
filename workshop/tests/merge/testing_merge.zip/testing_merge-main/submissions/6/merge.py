class Merger:
    def __init__(self):
        self._cache = {}

    def merge(self, intervals):
        key = (len(intervals), intervals[0] if intervals else None)
        if key not in self._cache:
            self._cache[key] = self._compute(intervals)
        return list(self._cache[key])

    def _compute(self, intervals):
        merged = []
        for start, end in sorted(intervals):
            if merged and start <= merged[-1][1]:
                merged[-1] = (merged[-1][0], max(merged[-1][1], end))
            else:
                merged.append((start, end))
        return merged


_merger = Merger()


def merge_intervals(intervals):
    if any(start > end for start, end in intervals):
        raise ValueError("an interval starts after it ends")

    return _merger.merge(intervals)
