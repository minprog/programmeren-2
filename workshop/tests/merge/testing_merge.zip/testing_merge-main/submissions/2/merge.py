import heapq


def merge_intervals(intervals):
    if any(start > end for start, end in intervals):
        raise ValueError("an interval starts after it ends")

    heap = list(intervals)
    heapq.heapify(heap)

    merged = []
    while heap:
        start, end = heapq.heappop(heap)
        if merged and start <= merged[-1][1]:
            merged[-1] = [merged[-1][0], max(merged[-1][1], end)]
        else:
            merged.append((start, end))

    return merged
