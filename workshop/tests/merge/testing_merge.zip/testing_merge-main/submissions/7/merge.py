def merge_intervals(intervals):
    if any(start > end for start, end in intervals):
        raise ValueError("an interval starts after it ends")

    intervals.sort()
    return merge_rest(intervals)


def merge_rest(rest):
    if len(rest) < 2:
        return rest

    first, second = rest[0], rest[1]
    if second[0] <= first[1]:
        rest[:2] = [(first[0], max(first[1], second[1]))]
        return merge_rest(rest)

    return rest[:1] + merge_rest(rest[1:])
