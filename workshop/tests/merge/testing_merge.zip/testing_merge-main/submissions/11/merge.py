def merge_intervals(intervals):
    if any(start > end for start, end in intervals):
        raise ValueError("an interval starts after it ends")

    if len(intervals) == 0:
        return None
    if len(intervals) == 1:
        return [tuple(intervals[0])]

    middle = len(intervals) // 2
    left = merge_intervals(intervals[:middle])
    right = merge_intervals(intervals[middle:])

    merged = []
    for start, end in sorted(left + right):
        if merged and start <= merged[-1][1]:
            merged[-1] = (merged[-1][0], max(merged[-1][1], end))
        else:
            merged.append((start, end))

    return merged
