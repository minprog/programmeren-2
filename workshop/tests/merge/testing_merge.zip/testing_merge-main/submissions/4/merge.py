def merge_intervals(intervals):
    if any(start > end for start, end in intervals):
        raise ValueError("an interval starts after it ends")

    end_for_start = {}
    for start, end in intervals:
        end_for_start[start] = end

    merged = []
    for start in sorted(end_for_start):
        end = end_for_start[start]
        if merged and start <= merged[-1][1]:
            merged[-1] = (merged[-1][0], max(merged[-1][1], end))
        else:
            merged.append((start, end))

    return merged
