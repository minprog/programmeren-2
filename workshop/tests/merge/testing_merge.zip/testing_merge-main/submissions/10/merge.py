def merge_intervals(intervals):
    if any(start > end for start, end in intervals):
        raise ValueError("an interval starts after it ends")

    parent = list(range(len(intervals)))

    def find(i):
        while parent[i] != i:
            parent[i] = parent[parent[i]]
            i = parent[i]
        return i

    for i in range(len(intervals)):
        for j in range(i + 1, len(intervals)):
            a, b = intervals[i], intervals[j]
            if a[0] <= b[1] and b[0] <= a[1]:
                parent[find(i)] = find(j)

    groups = {}
    for i, interval in enumerate(intervals):
        groups.setdefault(find(i), []).append(interval)

    merged = []
    for members in groups.values():
        if len(members) > 1:
            merged.append((min(s for s, _ in members), max(e for _, e in members)))

    return sorted(merged)
